﻿using System;

namespace SampleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Printing Values from 1 to 10");
            for (int i=0; i<=10; i++)
            {
                Console.WriteLine("Printing ", i);
            }
        }
    }
}
